import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
import yfinance as yf
import plotly.graph_objects as go
from datetime import datetime, timedelta
import streamlit as st

def main():
    st.title("Stock Price Forecast")
    
    symbol = st.text_input("Enter the ticker symbol of the company")
    if not symbol:
        st.warning("Please enter a ticker symbol")
        return

    st.subheader(f"Stock Price Forecast for {symbol}")
    if st.button("Predict"):
        predict_stock_price(symbol)

def predict_stock_price(symbol):
    start = pd.to_datetime('2004-08-01')
    end = datetime.today().date()

    data = yf.download(symbol, start=start, end=end)

    X = data[['Open', 'High', 'Low', 'Volume']]
    y = data['Close']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = LinearRegression()
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    r2 = r2_score(y_test, y_pred)
    st.write(symbol + ' R-squared:', r2)

    latest_data = yf.download(tickers=symbol, period='1d', interval='1m')
    latest_features = latest_data[['Open', 'High', 'Low', 'Volume']]

    next_day_open = model.predict(latest_features)[0]
    next_day_close = next_day_open + y_pred.mean() - X_train['Open'].mean()
    st.write(symbol + ' Next day open prediction:', next_day_open)
    st.write(symbol + ' Next day close prediction:', next_day_close)

    today_features = latest_features.iloc[-1].values.reshape(1, -1)
    today_open = model.predict(today_features)[0]
    today_close = today_open + y_pred.mean() - X_train['Open'].mean()
    st.write(symbol + ' Today opening price prediction:', today_open)
    st.write(symbol + ' Today closing price prediction:', today_close)

    current_close_price = latest_data['Close'].iloc[-1]
    st.write(symbol + ' Current closing price:', current_close_price)

    last_predicted_price = predicted_prices[-1]
    if last_predicted_price > current_close_price:
        recommendation = 'Buy'
    elif last_predicted_price < current_close_price:
        recommendation = 'Sell'
    else:
        recommendation = 'Hold'
    st.write('Investor Recommendation:', recommendation)

    date_str = st.text_input("Enter the date for stock price prediction (YYYY-MM-DD): ")
    prediction_date = pd.to_datetime(date_str).date()

    next_day = prediction_date
    next_5_days = [(prediction_date + timedelta(days=i)).strftime('%Y-%m-%d') for i in range(5)]
    next_day_features = latest_features.iloc[-1].values.reshape(1, -1)
    predicted_prices = []
    predicted_opens = []
    predicted_closes = []
    for day in next_5_days:
        predicted_price = model.predict(next_day_features)[0]
        predicted_prices.append(predicted_price)
        predicted_opens.append(next_day_open)
        predicted_closes.append(next_day_close)
        next_day_features[0][0] = predicted_price

    fig = go.Figure(data=[go.Candlestick(x=data.index, open=data['Open'], high=data['High'], low=data['Low'], close=data['Close'], name=symbol + ' Historical prices')])
    fig.add_trace(go.Scatter(x=[prediction_date] + [datetime.strptime(day, '%Y-%m-%d') for day in next_5_days], y=[current_close_price] + predicted_prices, name=symbol + ' Predicted prices', mode='lines+markers'))
    fig.add_trace(go.Scatter(x=[prediction_date] + [datetime.strptime(day, '%Y-%m-%d') for day in next_5_days], y=[current_close_price] + predicted_closes, name=symbol + ' Predicted CLOSE', mode='lines+markers'))
    fig.add_trace(go.Scatter(x=[prediction_date] + [datetime.strptime(day, '%Y-%m-%d') for day in next_5_days], y=[current_close_price] + predicted_opens, name=symbol + ' predicted_opens', mode='lines+markers'))
    fig.update_layout(title=symbol + ' Stock Price Forecast')

    # Display the chart using st.plotly_chart
    st.plotly_chart(fig)

    # Create a dataframe for actual and predicted prices
    dates = [prediction_date] + [datetime.strptime(day, '%Y-%m-%d') for day in next_5_days]
    actual_prices = [current_close_price] + predicted_prices
    predicted_close_prices = [current_close_price] + predicted_closes

    price_df = pd.DataFrame({'Date': dates, 'Actual Price': actual_prices, 'Predicted Close Price': predicted_close_prices})
    st.write('Actual and Predicted Prices:')
    st.dataframe(price_df)

    # Display the historical data along with current data
    st.subheader('Historical and Current Data')
    st.write(data)

if __name__ == "__main__":
    main()
