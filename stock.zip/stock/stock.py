import pandas as pd
import streamlit as st
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
import yfinance as yf
import plotly.graph_objects as go
from datetime import datetime, timedelta

def main():
    st.title("Stock Price Forecast")
    
    symbol = st.text_input("Enter the ticker symbol of the company")
    if not symbol:
        st.warning("Please enter a ticker symbol")
        return

    st.subheader(f"Stock Price Forecast for {symbol}")
    if st.button("Predict"):
        predict_stock_price(symbol)


def predict_stock_price(symbol):
    start = pd.to_datetime('2004-08-01')
    end = datetime.today().date()
    
    data = yf.download(symbol, start=start, end=end)
    
    X = data[['Open', 'High', 'Low', 'Volume']]
    y = data['Close']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    model = LinearRegression()
    model.fit(X_train, y_train)
    
    y_pred = model.predict(X_test)
    r2 = r2_score(y_test, y_pred)
    st.write(symbol + ' R-squared:', r2)
    
    latest_data = yf.download(tickers=symbol, period='1d', interval='1m')
    latest_features = latest_data[['Open', 'High', 'Low', 'Volume']]
    next_day_open = model.predict(latest_features)[0]
    next_day_close = next_day_open + y_pred.mean() - X_train['Open'].mean()
    st.write(symbol + ' Next day open prediction:', next_day_open)
    st.write(symbol + ' Next day close prediction:', next_day_close)
    
    today_features = latest_features.iloc[-1].values.reshape(1, -1)
    today_open = model.predict(today_features)[0]
    st.write(symbol + ' Today opening price prediction:', today_open)

    current_close_price = latest_data['Close'].iloc[-1]
    st.write(symbol + ' Current closing price:', current_close_price)

    current_open_price = latest_data['Open'].iloc[-1]
    st.write(symbol + ' Current opening price:', current_open_price)
    
   
    next_day = datetime.today() + timedelta(days=1)
    next_5_days = [(next_day + timedelta(days=i)).strftime('%Y-%m-%d') for i in range(5)]
    next_day_features = latest_features.iloc[-1].values.reshape(1, -1)
    predicted_prices = []
    predicted_opens = []
    predicted_closes = []
    for day in next_5_days:
        predicted_price = model.predict(next_day_features)[0]
        predicted_prices.append(predicted_price)
        predicted_opens.append(next_day_open)
        predicted_closes.append(next_day_close)
        next_day_features[0][0] = predicted_price
    
    fig = go.Figure(data=[go.Candlestick(
        x=data.index, 
        open=data['Open'], 
        high=data['High'], 
        low=data['Low'], 
        close=data['Close'],
        increasing_line_color='green',  # Set color for increasing prices
        decreasing_line_color='red'  # Set color for decreasing prices
    )])
    fig.add_trace(go.Scatter(x=[next_day] + [datetime.strptime(day, '%Y-%m-%d') for day in next_5_days], y=[current_close_price] + predicted_prices, name=symbol + ' Predicted prices', mode='lines+markers', line=dict(color='blue')))
    fig.add_trace(go.Scatter(x=[next_day] + [datetime.strptime(day, '%Y-%m-%d') for day in next_5_days], y=[current_open_price] + predicted_opens, name=symbol + ' Predicted opens', mode='lines+markers', line=dict(color='orange')))
    fig.add_trace(go.Scatter(x=[next_day] + [datetime.strptime(day, '%Y-%m-%d') for day in next_5_days], y=[current_close_price] + predicted_closes, name=symbol + ' Predicted CLOSE', mode='lines+markers', line=dict(color='purple')))

    fig.update_layout(title=symbol + ' Stock Price Forecast')
    fig.show()
    
    display_historical_data(symbol)
    display_predicted_data(symbol, y_test, y_pred)

def display_historical_data(symbol):
    start = pd.to_datetime('2004-08-01')
    end = datetime.today().date()
    
    data = yf.download(symbol, start=start, end=end)
    st.subheader(f"Historical Data for {symbol}")
    st.write(data.head(10))

def display_predicted_data(symbol, actual_values, predicted_values):
    data = pd.DataFrame({'Actual Close': actual_values, 'Predicted Close': predicted_values})
    st.subheader(f"Predicted vs Actual Data for {symbol}")
    st.write(data.head(10))


    fig = go.Figure()
    fig.add_trace(go.Scatter(x=data.index, y=data['Actual Close'], name='Actual Close'))
    fig.add_trace(go.Scatter(x=data.index, y=data['Predicted Close'], name='Predicted Close'))
    fig.update_layout(title=f"Predicted vs Actual Close Price for {symbol}")
    st.plotly_chart(fig)
    
if __name__ == "__main__":
    main()
